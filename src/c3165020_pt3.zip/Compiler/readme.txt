** Compiler Design Project **
		** Part 1**
** Robert Logan - C3165020 **

This project has been compiled and run under Java 8.

To Compile:
	Unzip all files into working directory
	Place input text file into unzipped folder
	Run "javac Compiler/*.java" from command line

To Run:
	Run "java Compiler.Part1 'filename.txt'" where 'filename.txt' is the name of the input text file

A program listing called "P1Output.txt" will be placed into the working directory once the program has exited.
NOTE1: Format of the program listing is not 100% accurate, but the idea is there.
NOTE2: This project makes use of code posted by Mike Hannaford on the subject Bulletin Board  